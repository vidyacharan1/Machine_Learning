from typing import List
import numpy as np
import pandas as pd
import random
from svm_binary import Trainer


class Trainer_OVO:
    def __init__(self, kernel, C=None, n_classes = -1, **kwargs) -> None:
        self.kernel = kernel
        self.C = C
        self.n_classes = n_classes
        self.kwargs = kwargs
        self.svms = [] # List of Trainer objects [Trainer]
    
    def _init_trainers(self):
        #TODO: implement
        #Initiate the svm trainers 
        # Create binary classifier for each pair of classes
        for i in range(self.n_classes):
            for j in range(i + 1, self.n_classes):
                object = Trainer(self.kernel,"OvO", i, j, C=self.C, **self.kwargs)
                self.svms.append(object)
        #pass
    
    def fit(self, train_data_path:str, max_iter=None)->None:
        #TODO: implement
        #Store the trained svms in self.svms
        for i in range(len(self.svms)):
            self.svms[i].fit(train_data_path)
        #pass
    
    def predict(self, test_data_path:str)->np.ndarray:
        #TODO: implement
        #Return the predicted labels
        X_test = pd.read_csv(test_data_path)
        n_samples = X_test.shape[0]
        n_svms = len(self.svms)
        pred_list = []
        for i in range(n_svms):
            pred_list.append(self.svms[i].predict(test_data_path))
        
        final_pred = np.zeros((n_samples,1))
        for i in range(n_samples):
            arr_for_samples = []
            for j in range(n_svms):
                arr_for_samples.append(pred_list[j][i])
        
            final_pred[i] = max(set(arr_for_samples[0]), key = arr_for_samples.count)        
        return final_pred
        

        # print(pred_list)
        # pred_list = np.array(pred_list).squeeze()
        # pred_list = np.argmax(pred_list, axis = 1) + 1
        # print(pred_list)
        # return pred_list

        # overall_list = []
        # for i in range(len(self.svms)):
        #     preds = self.svms[i].predict(test_data_path)
        #     overall_list.append(preds)

        # overall_list = np.array(overall_list)
        # pred_list = np.zeros((overall_list.shape[1],1))
        # for j in range(overall_list.shape[1]):
        #     col_extract = overall_list[:,j]
        #     pred_list[j] = mode(col_extract)
        
        # return pred_list

        # MAKING PREDICTIONS   
        # 1) Get the predictions from one SVM
        # 2) Using these predictions, keep count of how many times a particular sample has been classified as class i or class j
        # 3) When done for all SVMs, the final prediction for a sample is the class that has the highest count
        # 4) Store those final predictions for all samples and return
        
        

        # for i in range(len(overall_list)):
            
        
        #     overall_list = np.array(overall_list).squeeze()
        # print("overall_list shape:", overall_list.shape)
        # print(overall_list)

        # pred_list = np.argmax(overall_list, axis = 1) + 1
        # print("pred_list shape:", pred_list.shape)
        # return pred_list
        pass 

class Trainer_OVA:
    def __init__(self, kernel, C=None, n_classes = -1, **kwargs) -> None:
        self.kernel = kernel
        self.C = C
        self.n_classes = n_classes
        self.kwargs = kwargs
        self.svms = [] # List of Trainer objects [Trainer]
    
    def _init_trainers(self):
        #TODO: implement
        #Initiate the svm trainers 
        self.svms = []
        for i in range(self.n_classes):
            # NOTE: POSSIBLE BUG
            object = Trainer(self.kernel, "multi", i + 1, C=self.C, **self.kwargs)
            self.svms.append(object)
            
        #pass
    
    def fit(self, train_data_path:str, max_iter=None)->None:
        #TODO: implement
        #Store the trained svms in self.svms
        for i in range(self.n_classes):
            self.svms[i].fit(train_data_path)
            
         
    
    def predict(self, test_data_path:str)->np.ndarray:
        #TODO: implement
        #Return the predicted labels
        test_data = pd.read_csv(test_data_path)
        # X_test = np.array(test_data.iloc[:,2:])
        
        
        # fin_arr = np.zeros((267,1))
        # for i in range(267):
        #     for j in range(10):
        #         if self.svms[j].predict(test_data_path)[i][0] == 1:
        #             fin_arr[i][0] = j
        #         else :
        #             fin_arr[i][0] = random.randit(0,9)
        
        # return fin_arr
        
        classify_list = []
        for j in range(self.n_classes):
            predictions = self.svms[j].predict(test_data_path)
            classify_list.append(predictions)
        
        classify_list = np.array(classify_list).squeeze()
        
        #print(classify_list)
        #print(classify_list.shape)
        
        predictions_final = np.argmax(classify_list, axis = 0) + 1


        #print(predictions_final)

        return predictions_final
                
            
        
        #pass 
