from typing import List
import numpy as np
import pandas as pd
import qpsolvers
import kernel 
from cvxopt import matrix, solvers

class Trainer:
    def __init__(self,kernel,classify=None,classtype1=None,classtype2=None,C=None,**kwargs) -> None:
        self.kernel = kernel
        self.kwargs = kwargs
        self.C=C
        self.support_vectors:List[np.ndarray] = []
        self.support_vector_labels=[]
        self.alpha = None
        self.b = 0
        self.classify = classify
        self.classtype1 = classtype1
        self.classtype2 = classtype2
     
    
    def fit(self, train_data_path:str)->None:
        #TODO: implement
        #store the support vectors in self.support_vectors
        if self.classify == "binary":
            train_data = pd.read_csv(train_data_path)
            X_train = np.array(train_data.iloc[:,1:-1])
            values = train_data['y']
            y_train = np.zeros((X_train.shape[0],1))
        elif self.classify == "multi":
            train_data = pd.read_csv(train_data_path)
            X_train = np.array(train_data.iloc[:,2:])
            values = train_data['y']
            y_train = np.zeros((X_train.shape[0],1))
            
        else:
            train_data = pd.read_csv(train_data_path)
            X_train = np.array(train_data.iloc[:,2:])
            values = train_data['y']
            y_train = np.zeros((X_train.shape[0],1))
            
        
        if self.classify == "binary":
            for i in range(y_train.shape[0]):
                if values[i] == 0:
                    y_train[i][0] = -1
                else:
                    y_train[i][0]= 1
        elif self.classify == "multi":
            for i in range(y_train.shape[0]):
                if values[i] == self.classtype1:
                    y_train[i][0] = 1
                else:
                    y_train[i][0]= -1
        else:
            cnt = 0
            for i in range(y_train.shape[0]):

                if values[i] == self.classtype1:
                    cnt = cnt + 1
                elif values[i] == self.classtype2:
                    cnt = cnt + 1
            X_new = np.zeros((cnt, X_train.shape[1]))
            y_new = np.zeros((cnt,1))
            count2 = 0
            for i in range(y_train.shape[0]):
                if values[i] == self.classtype1:
                    X_new[count2] = X_train[i]
                    y_new[count2][0] = 1
                    count2 = count2 + 1
                elif values[i] == self.classtype2:
                    X_new[count2] = X_train[i]
                    y_new[count2][0] = -1
                    count2 = count2 + 1
            X_train = X_new
            y_train = y_new

        
                
            
        #y_train_new = np.reshape(y_train,(267,1))
        #y_train = y_train_new.T
        #print(y_train)
        #print(y_train.shape)
        # print(X_train[0:3])

        K = self.kernel(X_train, X_train, **self.kwargs)
        # Quadratic programming solving
        n_samples = X_train.shape[0]
        #P = matrix(K * np.outer(y_train, y_train))
        #q = matrix(-np.ones(n_samples))
        #G = matrix(np.vstack((-np.eye(n_samples), np.eye(n_samples))))
        #h = matrix(np.hstack((np.zeros(n_samples), self.C * np.ones(n_samples))))
        #A = matrix(y_train.reshape(1, -1))
        #print(A.shape)
        #b = matrix(np.array([0.0]))
        #alpha = solvers.qp(P, q, G, h, A, b)
        P = matrix(np.matmul(y_train,y_train.T) * K)
        q = matrix(np.ones((n_samples, 1)) * -1)
        A = matrix(y_train.reshape(1, -1))
        b = matrix(np.zeros(1))          
        G = matrix(np.vstack((np.eye(n_samples) * -1, np.eye(n_samples))))        
        h = matrix(np.vstack((np.zeros((n_samples,1)), np.ones((n_samples,1)) * self.C)))
        #alpha = qpsolvers.solve_qp(P, q, G, h, A, b,solver='ecos')
        alpha = solvers.qp(P, q, G, h, A, b, solver='cvxopt')
        # print(alpha['x'])
                
        # Computing support vectors
        alpha = np.array(alpha['x'])
        # print(alpha)
        #sv_indices =  np.where(alpha['x'] > 1e-5)[0]
        sv_indices = (alpha>1e-5).flatten()
        #print(sv_indices)
        self.support_vectors = X_train[sv_indices]
        #print(self.support_vectors)
        self.support_vector_labels = y_train[sv_indices]
        self.alpha = alpha[sv_indices]
        #print(self.alpha)
        # compute kernel matrix of support vectors
        K = self.kernel(X_train, self.support_vectors, **self.kwargs)
        #print(K)
        #for i in range(X_train.shape[0]):
          #  for j in range(self.alpha.shape[0]):
           #     K[i][j] = self.kernel(X_train[i],self.support_vectors[j],**self.kwargs)
        
        
        # compute b
        
        # total = 0
        # for j in range(self.alpha.shape[0]):
        #     total += alpha[j]*y_train[j]*K[j]
        # print(total)
        K_svm = self.kernel(self.support_vectors, self.support_vectors, **self.kwargs)
        # self.b = np.mean(y_train[sv_indices] - np.sum(total, axis=0))
        matmult = np.zeros((self.alpha.shape[0],1))
        for i in range(self.alpha.shape[0]):
            for j in range(self.alpha.shape[0]):
                matmult[i] += self.alpha[j][0]*K_svm[j][i]*self.support_vector_labels[j][0]
        
        self.b = np.mean(self.support_vector_labels - matmult)             
        #print(self.support_vector_labels.shape, "bias:",self.b)
        
    
    
    def predict(self, test_data_path:str)->np.ndarray:
        #TODO: implement
        #Return the predicted labels as a numpy array of dimension n_samples on test data
        test_data = pd.read_csv(test_data_path)
        if self.classify == "binary":
            X_test = np.array(test_data.iloc[:,1:-1])
        else:
            X_test = np.array(test_data.iloc[:,2:])
            

        # print("bias type:", type(self.b))
        # print("shape of bias:",self.b.shape)

        K = self.kernel(self.support_vectors, X_test, **self.kwargs)
        tot = np.zeros((X_test.shape[0],1))
        
        #for i in range(self.alpha.shape[0]):
            #tot += self.alpha[i]*self.support_vector_labels[i]*K[i]
        for i in range(X_test.shape[0]):
            for j in range(self.alpha.shape[0]):
                tot[i][0] += self.alpha[j][0]*K[j][i]*self.support_vector_labels[j][0]
        #print(tot)
        pred = tot+self.b
        #print(pred)

        if self.classify == "binary":
            for i in range(X_test.shape[0]):
                if pred[i][0] > 0:
                    pred[i][0] = 1
                else:
                    pred[i][0] = 0
            return pred
        elif self.classify == "multi" :
            return pred
        else: 
            for i in range(X_test.shape[0]):
                if pred[i][0] > 0:
                    pred[i][0] = self.classtype1
                else:
                    pred[i][0] = self.classtype2
            return pred

        
        #return np.sign(np.sum(self.alpha * self.support_vectors * K, axis=1) + self.b)
        #return np.sign(np.sum(tot, axis=0) + self.b)
        #pass