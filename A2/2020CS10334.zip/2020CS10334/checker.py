import svm_binary
import svm_multiclass
import matplotlib.pyplot as plt
import kernel
import numpy as np
import pandas as pd


C=1
kwargs = {'gamma':1e-1, 'degree':2, 'coeff':1}
classify = "OvO"
classtype1 = None
classtype2 = None

# def train_and_test(kernel, train_data_path, test_data_path, classify, classtype1, classtype2, C,**kwargs):
#         train_data = pd.read_csv(train_data_path)
#         test_data = pd.read_csv(test_data_path)
#         y_test = test_data['y'].to_numpy()
#         object = svm_binary.Trainer(kernel, classify, classtype1, classtype2, C,**kwargs)
#         object.fit(train_data_path)
        
#         y_pred = object.predict(test_data_path).squeeze()

#         return np.mean(y_pred == y_test)

           
        
# accu = train_and_test(kernel.linear, 'bi_train.csv', 'bi_val.csv',"binary",None, None, C, **kwargs)
# print(accu)        
  
# accu = train_and_test(kernel.rbf, 'bi_train.csv', 'bi_val.csv',"binary",None, None,C, **kwargs)
# print(accu)

# accu = train_and_test(kernel.laplacian, 'bi_train.csv', 'bi_val.csv',"binary",None, None,C, **kwargs)
# print(accu)


train_data = pd.read_csv('multi_train.csv')
test_data = pd.read_csv('multi_val.csv')
y_test = test_data['y'].to_numpy()
object = svm_multiclass.Trainer_OVO(kernel.rbf,C,10,**kwargs)
object._init_trainers()
object.fit('multi_train.csv')
y_pred = object.predict('multi_val.csv').squeeze()


cnt_matching_values = 0
for i in range(len(y_pred)):
        cnt_matching_values += (y_pred[i] == y_test[i])
#print(cnt_matching_values/len(y_pred))
#print(np.mean(y_pred == y_test))



# train_data = pd.read_csv('multi_train.csv')
# test_data = pd.read_csv('multi_val.csv')
# y_test = test_data['y'].to_numpy().reshape(-1,1)
# #print(y_test.shape)
# object = svm_multiclass.Trainer_OVA(kernel.rbf,C,10,**kwargs)
# object._init_trainers()
# object.fit('multi_train.csv')
# #print("Fitting done!")
# y_pred = object.predict('multi_val.csv').squeeze()
# #print("Predicting done!")

# print(np.mean(y_pred == y_test))


# acc_values = [0.53,0.89,0.89,0.89]
# C_values= [0.01,0.1,1,10]

# plt.plot(C_values, acc_values, marker='o')
# plt.title('Accuracy graph')
# plt.xlabel('C values')
# plt.ylabel('Accuracy')
# plt.show()