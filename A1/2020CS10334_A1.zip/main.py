﻿import pandas as pd
import numpy as np
import argparse

np.seterr(all='warn')

parser = argparse.ArgumentParser()
parser.add_argument('--train_path', type=str, required=True)
parser.add_argument('--test_path', type=str, required=True)
parser.add_argument('--val_path', type=str, required=True)
parser.add_argument('--out_path', type=str, required=True)
parser.add_argument('--section', type=int, required=False)
args = parser.parse_args()

df_train=pd.read_csv(args.train_path,header=None)
df_val=pd.read_csv(args.val_path,header=None)
df_test=pd.read_csv(args.test_path,header=None)

# df_train=pd.read_csv("C:/Users/91827/OneDrive - IIT Delhi/Desktop/train.csv",header=None)
# df_val=pd.read_csv("C:/Users/91827/OneDrive - IIT Delhi/Desktop/validation.csv",header=None)
# df_test=pd.read_csv("C:/Users/91827/OneDrive - IIT Delhi/Desktop/test.csv",header=None)

sample_test = df_test[0].to_numpy().reshape(-1,1)

X_train_df=df_train.drop([0,1],axis=1)
X_val_df=df_val.drop([0,1],axis=1)
X_test_df=df_test.drop([0],axis=1)

y_train_df=df_train[1]
y_val_df=df_val[1]

X_train=df_train.to_numpy()
X_val=df_val.to_numpy()
X_test=df_test.to_numpy()

y_train=X_train[:,1].reshape(-1,1)
y_val=X_val[:,1].reshape(-1,1)

# drop the first and second columnof train and validation set
X_train=np.delete(X_train,[0,1],axis=1)
X_val=np.delete(X_val,[0,1],axis=1)
X_test=np.delete(X_test,[0],axis=1)


if(args.section == 1):
    def gradient_descent_maxit(X,y,alpha=0.001,maxit=1000):
        samples,features=X.shape
        w=np.ones(features).reshape(-1,1)
        b=np.zeros(samples).reshape(-1,1)
        cost_func=np.zeros(maxit)
        mae = np.zeros(maxit)
        plot_cost=[]
        for i in range(maxit):
            y_pred=np.dot(X,w)+b
            dw=np.dot(X.T,y_pred-y)/samples
            db=np.sum(y_pred-y)/samples
            w=w-alpha*dw
            b=b-alpha*db
            cost_func[i]=np.square(y_pred-y).mean()
            mae[i]=np.abs(y_pred-y).mean()
        return w,b,cost_func,mae

    w,b,cost_func,mae=gradient_descent_maxit(X_val,y_val)
    b_new = array=np.ones(X_test.shape[0])*b[0]

    gd_pred=np.dot(X_test,w)+b_new
    gd_pred=gd_pred[:,0].reshape(-1,1)

    output_arr = np.concatenate((sample_test, gd_pred), axis=1)
    np.savetxt('output_3_gd.csv', output_arr, delimiter=',', fmt='%s')

    # import matplotlib.pyplot as plt
    # plt.plot(cost_func)

    def gradient_descent_reltol(X,y,alpha=0.001,threshold=0.01, maxit=1000):
        samples,features=X.shape
        w=np.ones(features).reshape(-1,1)
        b=np.zeros(samples).reshape(-1,1)
        cost_func=[]
        mae=[]

        for i in range(maxit):
            y_pred=np.dot(X,w)+b
            dw=np.dot(X.T,y_pred-y)/samples
            db=np.sum(y_pred-y)/samples
            w=w-alpha*dw
            b=b-alpha*db
            cost_func.append(np.square(y_pred-y).mean())
            mae.append(np.abs(y_pred-y).mean())
            if i>0:
                if abs(cost_func[i]-cost_func[i-1])<threshold:
                    break
        return w,b,cost_func,mae

    w,b,cost_func,mae=gradient_descent_reltol(X_val,y_val)
    b_new = np.ones(X_test.shape[0])*b[0]

    gd_pred=np.dot(X_test,w)+b_new
    gd_pred=gd_pred[:,0].reshape(-1,1)

    output_arr = np.concatenate((sample_test, gd_pred), axis=1)
    # np.savetxt('output_3_reltol.csv', output_arr, delimiter=',', fmt='%s')

if(args.section == 2):
    def ridge_regression(X,y,alpha,lambda_,maxit):
        samples,features=X.shape
        w=np.ones(features).reshape(-1,1)
        b=np.zeros(samples).reshape(-1,1)
        cost_func=[]
        mae_val=[]
        mse_val=[]
        for i in range(maxit):
            y_pred=np.dot(X,w)+b
            dw=(np.dot(X.T,y_pred-y)+(2*lambda_*w))/samples
            db=np.sum(y_pred-y)/samples
            w=w-alpha*dw
            b=b-alpha*db
            cost=np.square(y_pred-y).mean()+lambda_*np.square(w).mean()
            mae=np.abs(y_pred-y).mean()
            mse=np.square(y_pred-y).mean()
            cost_func.append(cost)
            mae_val.append(mae)
            mse_val.append(mse)
        return w,b,cost_func , cost_func[-1],mae_val[-1],mse_val[-1]

    alpha=0.001
    lambda_=25
    maxit=1000
    w,b,cost_func, final_cost,mse_final,mae_final=ridge_regression(X_train,y_train,alpha,lambda_,maxit)
    b_new = np.ones(X_test.shape[0])*b[0]
    print("mse_final: ",mse_final)
    print("mae_final: ",mae_final)

    gd_pred=np.dot(X_test,w)+b_new
    gd_pred=gd_pred[:,0].reshape(-1,1)

    output_arr = np.concatenate((sample_test, gd_pred), axis=1)
    np.savetxt('output_3_ridge.csv', output_arr, delimiter=',', fmt='%s')

if(args.section == 5):
    def sigmoid(z):
        z = np.array(z, dtype=float)
        return 1 / (1 + np.exp(-z))


    def cost_function(X, y, theta):
        m = len(y)
        h = sigmoid(np.dot(X, theta))
        J = -1/m * np.sum(y * np.log(h) + (1 - y) * np.log(1 - h))
        return J


    def gradient_descent(X, y, theta, alpha, num_iters):
        m = len(y)
        J_history = np.zeros((num_iters, 1))
        
        for i in range(num_iters):
            h = sigmoid(np.dot(X, theta))
            theta = theta - alpha * 1/m * np.dot(X.T, h - y)
            J_history[i] = cost_function(X, y, theta)
    
        return theta, J_history


    def predict(X, theta):
        prob = sigmoid(np.dot(X, theta))
        return np.round(prob)


    def logistic_regression(X, y, alpha, num_iters):
        m, n = X.shape
        thetas = np.zeros((n, 9))
        y_pred = np.zeros((m, 9))

        for i in range(9):
            y_new = np.where(y == i, 1, 0)
            theta, J_history = gradient_descent(X, y_new, np.zeros((n, 1)), alpha, num_iters)
            thetas[:, i] = theta.ravel()
            y_pred[:, i] = predict(X, theta).ravel()

        y_pred_final = np.argmax(y_pred, axis=1)+1
        return thetas, y_pred_final


    alpha = 0.1
    num_iters = 100

    thetas, y_pred = logistic_regression(X_train, y_train, alpha, num_iters)

    np.savetxt('output_3_classification.csv', y_pred, delimiter=',', fmt='%s')

# 3.8
def sigmoid(z):
    z = np.array(z, dtype=float)
    return 1 / (1 + np.exp(-z))

def cost_function(theta, X, y, lambda_reg=0.0):
    m = len(y)
    h = sigmoid(X @ theta)
    cost = -(1/m) * (y * np.log(h) + (1-y) * np.log(1-h)).sum() + (lambda_reg/(2*m)) * (theta[1:]**2).sum()
    return cost

def gradient(theta, X, y, lambda_reg=0.0):
    m = len(y)
    h = sigmoid(X @ theta)
    grad = (1/m) * X.T @ (h - y)
    grad[1:] = grad[1:] + (lambda_reg/m) * theta[1:]
    return grad

def predict(theta, X):
    h = sigmoid(X @ theta)
    return np.round(h)

def one_vs_all(X, y, num_labels, lambda_reg=0.0, alpha=0.1, num_iters=100):
    m, n = X.shape
    all_theta = np.zeros((num_labels, n+1)).reshape(-1, n+1)
    X = np.hstack((np.ones((m, 1)), X))
    initial_theta = np.zeros(n+1).reshape(-1,1)
    for i in range(1, num_labels+1):
        theta = initial_theta
        for iteration in range(num_iters):
            grad = gradient(theta, X, (y == i), lambda_reg)
            theta = theta - alpha * grad
        all_theta[i-1] = theta.reshape(-1)
    return all_theta

def predict_one_vs_all(all_theta, X):
    m = X.shape[0]
    X = np.hstack((np.ones((m, 1)), X))
    return np.argmax(sigmoid(X @ all_theta.T), axis=1) +1

alpha = 0.01
lambda_reg = 0
num_iters = 1000
num_labels = 9

all_theta = one_vs_all(X_train, y_train, num_labels, lambda_reg, alpha, num_iters)

# finding accuray of the model
final_theta = all_theta.reshape(num_labels, -1)
y_pred = predict_one_vs_all(final_theta, X_train)
print("Accuracy: ", (y_pred == y_train).mean())

# 3.4
import sklearn
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error


def sklearn_linear_regression(X_train, y_train, X_val, y_val):
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_val)
    mse = mean_squared_error(y_val, y_pred)
    mae = mean_absolute_error(y_val, y_pred)
    return mse, mae

mse ,mae=sklearn_linear_regression(X_train,y_train,X_val,y_val)

from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error

def sklearn_ridge_regression(X_train, y_train, X_val, y_val,alpha,reltol):
    ridge = Ridge(alpha=alpha,stopping_criterion='relative_improvement',tol=reltol)
    ridge.fit(X_train, y_train)
    y_pred = ridge.predict(X_val)
    mse = mean_squared_error(y_val, y_pred)
    mae = mean_absolute_error(y_val, y_pred)
    return mse, mae

import sklearn
from sklearn.feature_selection import SelectKBest, f_regression, SelectFromModel
from sklearn.linear_model import Ridge

def feature_selection(X_train, y_train, X_val, y_val, features=10):
    selector = SelectKBest(score_func=f_regression, k=features)
    selector.fit(X_train, y_train.T)
    selector.fit(X_val, y_val.T)
    X_train_new = selector.transform(X_train)
    X_val_new = selector.transform(X_val)
    
    return X_train_new, X_val_new


X_train_new, X_val_new = feature_selection(X_train, y_train, X_val, y_val, features=10)
mae,mse = sklearn_linear_regression(X_train_new, X_val_new)

import numpy as np
import pandas as pd

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=1)

def predict(X, theta):
    return sigmoid(np.dot(X, theta))

def cost_function(X, y, theta):
    m = len(y)
    predictions = predict(X, theta)
    error = (y * np.log(predictions)) + ((1 - y) * np.log(1 - predictions))
    cost = -1 / m * sum(error)
    grad = 1 / m * np.dot(X.transpose(), (predictions - y))
    return cost[0], grad

def gradient_descent(X, y, theta, alpha, iterations):
    cost_history = []
    for i in range(iterations):
        cost, grad = cost_function(X, y, theta)
        theta -= alpha * grad
        cost_history.append(cost)
    return theta, cost_history

def logistic_regression(X, y, alpha, iterations):
    theta = np.zeros(X.shape[1])
    y = np.array(y)
    theta, cost_history = gradient_descent(X, y, theta, alpha, iterations)
    return theta, cost_history

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error


df_train=pd.read_csv('D:/Projects/COL341/Data/2_d_train.csv')
df_test=pd.read_csv('D:/Projects/COL341/Data/2_d_test.csv')

train_data=df_train.to_numpy()
test_data=df_test.to_numpy()

X_train=train_data[:,:-1]
y_train=train_data[:,-1]
X_test=test_data[:,:-1]
y_test=test_data[:,-1]

# 3.7
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Load train and test csv files
train_2d = pd.read_csv('/content/2_d_train.csv')
test_2d = pd.read_csv('/content/2_d_test.csv')
train_5d = pd.read_csv('/content/5_d_train.csv')
test_5d = pd.read_csv('/content/5_d_test.csv')
train_10d = pd.read_csv('/content/10_d_train.csv')
test_10d = pd.read_csv('/content/10_d_test.csv')
train_100d = pd.read_csv('/content/100_d_train.csv')
test_100d = pd.read_csv('/content/100_d_test.csv')

# Train and evaluate linear regression model on each dataset
def train_and_evaluate(train, test):
    X_train = train.iloc[:,:-1]
    y_train = train.iloc[:,-1]
    X_test = test.iloc[:,:-1]
    y_test = test.iloc[:,-1]
    model = LinearRegression().fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    ein = mean_squared_error(y_train_pred, y_train)
    eout = mean_squared_error(y_test_pred, y_test)
    return ein, eout

ein_2d, eout_2d = train_and_evaluate(train_2d, test_2d)
ein_5d, eout_5d = train_and_evaluate(train_5d, test_5d)
ein_10d, eout_10d = train_and_evaluate(train_10d, test_10d)
ein_100d, eout_100d = train_and_evaluate(train_100d, test_100d)